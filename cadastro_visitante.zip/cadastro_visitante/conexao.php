<?php

$servername = "localhost";
$database = "brinquedotecaid";
$username = "root";
$password = "";

$conexao = mysqli_connect($servername, $username, $password, $database );



?>